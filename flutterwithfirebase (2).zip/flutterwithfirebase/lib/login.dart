import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  login() async {
    final email = emailController.text;
    final password = passwordController.text;

    FirebaseAuth auth = FirebaseAuth.instance;
    FirebaseFirestore db = FirebaseFirestore.instance;

    try {
      final UserCredential user = await auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      await db.collection("user").doc(user.user?.uid).get();

      await Future.delayed(Duration(seconds: 4));

      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          content: Text("Thankyou for your responses!~"),
          title: Text("USER LOGGED IN!"),
          actions: [
            TextButton.icon(
              onPressed: () {
                Navigator.pop(context);
              },
              label: Text("OK"),
              icon: const SizedBox.shrink(), 
            ),
          ],
        ),
      );
    } catch (err) {
      print("error!");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("CREDENTIAL ERROR!"),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: "Email",
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14.0),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              controller: passwordController,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14.0),
                ),
              ),
            ),
          ),




ElevatedButton.icon(onPressed: login, label: Text("login"), icon: Icon(Icons.app_registration_rounded),style: 
ElevatedButton.styleFrom(
  minimumSize: Size(160.0, 50.0)
),) 


        ],
      ),
    );
  }
}