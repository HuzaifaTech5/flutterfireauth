import 'package:flutter/material.dart';

class Post extends StatelessWidget {
  final Map data;
  Post({required this.data});

  @override
  Widget build (BuildContext context)  {
    return Container(
      margin: EdgeInsets.all(6.0),
      padding: EdgeInsets.all(6.0),
      decoration: BoxDecoration(
        border: Border.all(color:Colors.amber , width: 2.0)
      ),

      child: Column(
        children: [
          Image.network(data["image"], height: 300.0, width: 300.0, fit: BoxFit.cover,),
          Text(data["title"]),
          Text(data["description"]),
        ],
      ),
    );
  }

}