import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutterwithfirebase/login.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  register() async {
    final name = nameController.text;
    final email = emailController.text;
    final password = passwordController.text;
    FirebaseAuth auth = FirebaseAuth.instance;
    FirebaseFirestore db = FirebaseFirestore.instance;
    
    try {
      final UserCredential user = await auth.createUserWithEmailAndPassword(
        email: email, 
        password: password,
      );
      
      await db.collection("user").doc(user.user?.uid).set({
        "name": name,
        "email": email,
      });
      
      print("User Has been Registered!");
      Future.delayed(const Duration(seconds: 4));
      
      await showDialog(
        context: context, 
        builder: (context) => AlertDialog(
          title: const Text("User has been registered!"),
          content: const Text("Thankyou for you time!"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              }, 
              child: const Text("OK"),
            ),
          ],
        ));

      
        Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginPage()));
      
    } catch (err) {
      print("ERROR!");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          const Text(
            "Register page", 
            style: TextStyle(
              fontSize: 40.0, 
              color: Colors.lightBlueAccent,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              decoration: InputDecoration(
                labelText: "username",
                prefixIcon: const Icon(Icons.account_box_sharp),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14.0),
                ),
              ),
              controller: nameController,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.5),
            child: TextFormField(
              decoration: InputDecoration(
                labelText: "Email",
                prefixIcon: const Icon(Icons.email),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14.0),
                ),
              ),
              controller: emailController,
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextFormField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Password",
                prefixIcon: const Icon(Icons.lock),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14.0),
                ),
              ),
              controller: passwordController,
            ),
          ),
          ElevatedButton.icon(
            onPressed: register, 
            label: const Text("Register"), 
            icon: const Icon(Icons.app_registration_rounded), 
            style: ElevatedButton.styleFrom(
              minimumSize: const Size(160.0, 50.0),
            ),
          ),
        ],
      ),
    );
  }
}